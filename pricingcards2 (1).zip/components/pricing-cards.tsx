"use client"

import { Check, X, Sparkles, Star, Zap, Award, Gift } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"

// Define feature categories
const categories = [
  "ระบบ",
  "ระบบจัดการสินค้า",
  "ระบบการชำระเงิน",
  "การตลาด",
  "ระบบตัวแทน",
  "การจัดการคำสั่งซื้อ",
  "บัญชีโปรไฟล์",
  "ระบบบริการลูกค้า",
  "ระบบข้อความ",
  "ระบบตั้งค่า (API)",
  "อื่นๆ",
]

// Define features by category
const features = {
  ระบบ: [
    { name: "ระบบหลังบ้านทั้ง DESKTOP และ MOBILE", basic: true, pro: true, ultimate: true },
    { name: "ระบบหน้าร้าน WPA MOBILE และ PC", basic: true, pro: true, ultimate: true },
    {
      name: "การเข้าสู่ระบบด้วยการลงทะเบียนบัญชีผู้ใช้งาน, OTP EMAIL, FACEBOOK, LINE, GOOGLE",
      basic: true,
      pro: true,
      ultimate: true,
    },
    { name: "ระบบแสดงป๊อปอัพ/เมื่อมีคนสั่งซื้อ/เมื่อเรียกดูร้านค้า", basic: true, pro: true, ultimate: true },
    { name: "DIY ออกแบบหน้าร้านได้เอง", basic: true, pro: true, ultimate: true },
    { name: "ระบบปรับไอคอนปุ่มนำทาง", basic: true, pro: true, ultimate: true },
    { name: "ระบบการเปลี่ยนสีธีมของร้านค้า", basic: true, pro: true, ultimate: true },
  ],
  ระบบจัดการสินค้า: [
    { name: "จัดการหมวดหมู่สินค้า", basic: true, pro: true, ultimate: true },
    { name: "จัดการแบรนด์สินค้า", basic: true, pro: true, ultimate: true },
    { name: "การจัดหน่วยสินค้า", basic: true, pro: true, ultimate: true },
    { name: "ปรับแต่งสินค้า", basic: true, pro: true, ultimate: true },
    { name: "การแชร์โปสเตอร์สินค้า", basic: true, pro: true, ultimate: true },
    { name: "ราคาสำหรับสมาชิก", basic: true, pro: true, ultimate: true },
    { name: "สต็อก/ยอดขาย/การเข้าชมของสินค้า", basic: true, pro: true, ultimate: true },
    { name: "การรับคูปองสินค้าก่อนซื้อ", basic: true, pro: true, ultimate: true },
    { name: "ระบบการให้คะแนนสะสมจากการขาย", basic: true, pro: true, ultimate: true },
    { name: "ระบบสินค้าหลายขนาด-แบบ หลายระดับชั้น", basic: true, pro: true, ultimate: true },
    { name: "ระบบรีวิวสินค้า", basic: false, pro: true, ultimate: true },
    { name: "ระบบสินค้าหลายแบบ (คีย์, การจัดส่งโลจิสติก)", basic: false, pro: true, ultimate: true },
  ],
  ระบบการชำระเงิน: [
    { name: "การใช้คูปองก่อนชำระเงิน เลือกเปลี่ยนแปลงคูปอง", basic: true, pro: true, ultimate: true },
    { name: "การชำระเงินผ่าน PROMPTPAY STRIPE", basic: true, pro: true, ultimate: true },
    { name: "การชำระเงินผ่านบัตรเครดิต STRIPE", basic: true, pro: true, ultimate: true },
    { name: "การชำระเงินผ่าน PROMPTPAY เช็คสลิป", basic: true, pro: true, ultimate: true },
    { name: "การชำระเงินผ่าน TRUEMONEY", basic: true, pro: true, ultimate: true },
    { name: "การชำระเงินออฟไลน์พูดคุยส่วนตัว", basic: true, pro: true, ultimate: true },
  ],
  การตลาด: [
    { name: "ระบบสร้างและกระจายคูปอง", basic: true, pro: true, ultimate: true },
    { name: "ระบบเช็คอิน", basic: false, pro: false, ultimate: true },
    { name: "ระบบกิจกรรมลดราคา", basic: false, pro: true, ultimate: true },
    { name: "ระบบFLASHSALE", basic: true, pro: true, ultimate: true },
    { name: "ระบบการซื้อแบบกลุ่ม", basic: false, pro: false, ultimate: true },
    { name: "กิจกรรมตัดราคา", basic: false, pro: false, ultimate: true },
    { name: "ระบบเติมเงิน", basic: true, pro: true, ultimate: true },
    { name: "การใช้คะแนนสะสม", basic: true, pro: true, ultimate: true },
    { name: "Point Mall", basic: false, pro: true, ultimate: true },
    { name: "ส่วนลดสำหรับสมาชิกหลายระดับ VIP", basic: false, pro: true, ultimate: true },
    { name: "ระบบเกม", basic: false, pro: false, ultimate: true },
    { name: "ระบบพิมพ์ใบเสร็จ", basic: true, pro: true, ultimate: true },
    { name: "ระบบพิมพ์ใบปะหน้า", basic: false, pro: true, ultimate: true },
    { name: "ระบบประกาศ", basic: true, pro: true, ultimate: true },
    { name: "ระบบ BLOG", basic: true, pro: true, ultimate: true },
  ],
  ระบบตัวแทน: [
    { name: "ตั้งค่าคอมมิ���ชั่นได้ 3 แบบ", basic: false, pro: false, ultimate: true },
    { name: "ระบบสมัครตัวแทน", basic: false, pro: false, ultimate: true },
    { name: "แต่งตั้งตัวแทนที่กำหนด", basic: false, pro: false, ultimate: true },
    { name: "สร้างระดับตัวแทน", basic: false, pro: false, ultimate: true },
    { name: "ค่าคอมมิชชั่นแยกสำหรับสินค้าจัดจำหน่าย", basic: false, pro: false, ultimate: true },
    { name: "กฏการขึ้นระดับตัวแทน", basic: false, pro: false, ultimate: true },
    { name: "ระบบรหัสผู้แนะนำ", basic: false, pro: false, ultimate: true },
    { name: "การคำนวณค่าคอมมิชชั่น", basic: false, pro: false, ultimate: true },
    { name: "การประมาณการรายได้", basic: false, pro: false, ultimate: true },
    { name: "จัดการดาวน์ไลน์", basic: false, pro: false, ultimate: true },
    { name: "ลิงก์จัดจำหน่าย", basic: false, pro: false, ultimate: true },
    { name: "การถอนค่าคอมมิชชั่น", basic: false, pro: false, ultimate: true },
    { name: "รายละเอียดการสั่งซื้อค่าคอมมิชชั่น", basic: false, pro: false, ultimate: true },
    { name: "ใบแจ้งยอดรายเดือนค่าคอมมิชชั่น", basic: false, pro: false, ultimate: true },
  ],
  การจัดการคำสั่งซื้อ: [
    { name: "การชำระเงินคำสั่งซื้อ", basic: true, pro: true, ultimate: true },
    { name: "การยกเลิกคำสั่งซื้อ", basic: true, pro: true, ultimate: true },
    { name: "การยืนยันการรับสินค้า", basic: true, pro: true, ultimate: true },
    { name: "การติดตามพัสดุ (ทางตรง)", basic: true, pro: true, ultimate: true },
    { name: "การคืนเงิน/คืนสินค้า", basic: true, pro: true, ultimate: true },
    { name: "การแสดงความคิดเห็นสินค้า", basic: true, pro: true, ultimate: true },
  ],
  บัญชีโปรไฟล์: [
    { name: "การเปลี่ยนชื่อและภาพโปรไฟล์", basic: true, pro: true, ultimate: true },
    { name: "กระเป๋าเงินของฉัน", basic: true, pro: true, ultimate: true },
    { name: "การโอนยอดคงเหลือ", basic: true, pro: true, ultimate: true },
    { name: "รหัสความปลอดภัย", basic: true, pro: true, ultimate: true },
    { name: "การถอนค่าคอมมิชชั่น", basic: true, pro: false, ultimate: true },
    { name: "ผู้ตรวจสอบตัดจำหน่าย", basic: true, pro: false, ultimate: true },
    { name: "การสร้างสิทธิ์หรือเพิ่มแอดมิน", basic: true, pro: true, ultimate: true },
    { name: "ตั้งค่าบริการพิเศษ", basic: true, pro: true, ultimate: true },
  ],
  ระบบบริการลูกค้า: [
    { name: "บริการลูกค้าผ่าน QR Code", basic: true, pro: true, ultimate: true },
    { name: "ระบบบริการลูกค้า IM", basic: true, pro: true, ultimate: true },
  ],
  ระบบข้อความ: [
    { name: "การแจ้งเตือนข้อความระบบ", basic: true, pro: true, ultimate: true },
    { name: "การแจ้งเตือนข้อความ Email", basic: false, pro: false, ultimate: true },
    { name: "การแจ้งเตือนข้อความ Line", basic: true, pro: true, ultimate: true },
    { name: "การแจ้งเตือนข้อความในแอพ", basic: true, pro: true, ultimate: true },
  ],
  "ระบบตั้งค่า (API)": [
    { name: "Email", basic: true, pro: true, ultimate: true },
    { name: "ดึงข้อมูลสินค้าผ่าน Lazada, Shopee, Temu และ Amazon", basic: false, pro: false, ultimate: true },
    { name: "รองรับการใส่ GA 4", basic: true, pro: true, ultimate: true },
    { name: "รองรับการใส่ Facebook Pixel", basic: true, pro: true, ultimate: true },
    { name: "รองรับ SEO title, description, Image", basic: true, pro: true, ultimate: true },
    { name: "AI ลงสินค้าจัดหมวดหมู่", basic: true, pro: true, ultimate: true },
    { name: "ระบบนำเข้าสินค้า", basic: true, pro: true, ultimate: true },
    { name: "ระบบส่งออกสินค้า", basic: true, pro: true, ultimate: true },
    { name: "ใส่ Javascript ได้", basic: true, pro: true, ultimate: true },
  ],
  อื่นๆ: [{ name: "ระบบสร้างหน้า static พิเศษสำหรับ SEO", basic: true, pro: true, ultimate: true }],
}

export default function PricingCards() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set())
  const messengerBaseUrl = "https://www.facebook.com/messages/t/598196483371128/"

  // Create messenger links with pre-filled messages
  const basicMessengerUrl = `${messengerBaseUrl}?initial_message=${encodeURIComponent("ฉันสนใจเเพ็คเกจ Basic นี้")}`
  const proMessengerUrl = `${messengerBaseUrl}?initial_message=${encodeURIComponent("ฉันสนใจเเพ็คเกจ Pro นี้")}`
  const ultimateMessengerUrl = `${messengerBaseUrl}?initial_message=${encodeURIComponent("ฉันสนใจเเพ็คเกจ Ultimate นี้")}`

  const toggleCategory = (category: string) => {
    setExpandedCategories((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(category)) {
        newSet.delete(category)
      } else {
        newSet.add(category)
      }
      return newSet
    })
  }

  return (
    <div className="w-full max-w-7xl mx-auto p-4 md:p-8 relative">
      {/* Background decorative elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-purple-600 rounded-full mix-blend-overlay filter blur-xl opacity-20 animate-blob"></div>
      <div className="absolute top-40 right-10 w-32 h-32 bg-pink-600 rounded-full mix-blend-overlay filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
      <div className="absolute bottom-20 left-1/2 w-32 h-32 bg-orange-400 rounded-full mix-blend-overlay filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>

      {/* Logo and header */}
      <div className="text-center mb-16 relative">
        <div className="flex justify-center mb-8">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E0%B8%AA%E0%B8%99%E0%B9%80%E0%B8%99%20webdee-r3fCgExANK88uUbAHTQde003tI77Xa.png"
            alt="WEBREW-D Logo"
            width={300}
            height={100}
            className="object-contain"
          />
        </div>
        <h1 className="text-6xl font-bold bg-gradient-to-r from-orange-400 via-pink-500 to-purple-600 bg-clip-text text-transparent mb-6">
          แพ็คเกจราคา
        </h1>
        <p className="text-gray-400 text-xl whitespace-nowrap overflow-hidden text-ellipsis mx-auto md:text-lg lg:text-xl">
          เลือกแพ็คเกจที่เหมาะกับธุรกิจของคุณ เพื่อยกระดับประสบการณ์ลูกค้าและเพิ่มยอดขาย
        </p>

        {/* Decorative stars */}
        <div className="absolute top-0 left-1/4 text-orange-400 animate-pulse">
          <Star className="w-6 h-6 fill-orange-400" />
        </div>
        <div className="absolute bottom-0 right-1/4 text-pink-400 animate-bounce animation-delay-1000">
          <Star className="w-5 h-5 fill-pink-400" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
        {/* Basic Package */}
        <Card
          className={`border-2 bg-black/40 backdrop-blur-sm ${hoveredCard === 0 ? "border-orange-400 shadow-xl shadow-orange-900/20" : "border-orange-900/30"} 
            rounded-2xl transition-all duration-500 flex flex-col overflow-hidden transform ${hoveredCard === 0 ? "scale-105" : ""} h-full`}
          onMouseEnter={() => setHoveredCard(0)}
          onMouseLeave={() => setHoveredCard(null)}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-purple-500/5"></div>

          <CardHeader className="pb-8 pt-8 relative">
            <Badge className="absolute top-4 right-4 bg-orange-400/10 text-orange-400 hover:bg-orange-400/20 border-none text-base">
              เริ่มต้น
            </Badge>
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 rounded-full bg-orange-400/10 flex items-center justify-center">
                <Zap className="h-10 w-10 text-orange-400" />
              </div>
            </div>
            <CardTitle className="text-3xl font-bold text-center text-white">Basic Package</CardTitle>
            <div className="text-center mt-4 flex flex-col items-center justify-center">
              <span className="text-6xl font-bold bg-gradient-to-r from-orange-400 to-pink-500 bg-clip-text text-transparent">
                ฿590
              </span>
              <span className="text-sm text-gray-400 mt-1">รายเดือน</span>
              <span className="text-base text-gray-400 mt-2">
                หรือ <span className="font-semibold text-orange-400">฿5,900</span> รายปี
              </span>
            </div>
            <CardDescription className="text-center mt-4 text-lg text-gray-400 h-24 flex items-center justify-center">
              สำหรับผู้เริ่มต้นธุรกิจที่ต้องการระบบพื้นฐานเพื่อสร้างยอดขาย
            </CardDescription>
          </CardHeader>

          <CardContent className="flex-grow relative">
            <div className="space-y-4">
              {categories.map((category) => (
                <div key={`basic-${category}`} className="border-b border-gray-800 pb-4">
                  <button
                    onClick={() => toggleCategory(category)}
                    className="flex justify-between items-center w-full text-left font-medium text-white mb-2"
                  >
                    <span>{category}</span>
                    <span>{expandedCategories.has(category) ? "−" : "+"}</span>
                  </button>

                  {expandedCategories.has(category) && (
                    <div className="space-y-3 mt-2">
                      {features[category].map((feature) => (
                        <FeatureItem
                          key={`basic-${feature.name}`}
                          feature={feature.name}
                          available={feature.basic}
                          type="basic"
                        />
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Pro Package */}
        <Card
          className={`border-2 bg-black/40 backdrop-blur-sm ${hoveredCard === 1 ? "border-pink-500 shadow-xl shadow-pink-900/20" : "border-pink-900/30"} 
            rounded-2xl transition-all duration-500 flex flex-col relative overflow-hidden transform ${hoveredCard === 1 ? "scale-105" : ""} h-full`}
          onMouseEnter={() => setHoveredCard(1)}
          onMouseLeave={() => setHoveredCard(null)}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-pink-500/5 to-purple-500/5"></div>

          <div className="absolute -top-5 -right-5 w-32 h-32 rotate-12">
            <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-r from-pink-500 to-purple-600 shadow-lg transform rotate-45"></div>
            <div className="absolute top-[45px] right-[12px] text-white font-bold transform -rotate-45 text-lg">
              แนะนำ
            </div>
          </div>

          <CardHeader className="pb-8 pt-8 relative">
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 rounded-full bg-pink-400/10 flex items-center justify-center">
                <Award className="h-10 w-10 text-pink-400" />
              </div>
            </div>
            <CardTitle className="text-3xl font-bold text-center text-white">Pro Package</CardTitle>
            <div className="text-center mt-4 flex flex-col items-center justify-center">
              <span className="text-6xl font-bold bg-gradient-to-r from-pink-400 to-purple-500 bg-clip-text text-transparent">
                ฿999
              </span>
              <span className="text-sm text-gray-400 mt-1">รายเดือน</span>
              <span className="text-base text-gray-400 mt-2">
                หรือ <span className="font-semibold text-pink-400">฿11,999</span> รายปี
              </span>
            </div>
            <CardDescription className="text-center mt-4 text-lg text-gray-400 h-24 flex items-center justify-center">
              สำหรับธุรกิจที่ต้องการยกระดับประสบการณ์ลูกค้าและเพิ่มยอดขาย
            </CardDescription>
          </CardHeader>

          <CardContent className="flex-grow relative">
            <div className="space-y-4">
              {categories.map((category) => (
                <div key={`pro-${category}`} className="border-b border-gray-800 pb-4">
                  <button
                    onClick={() => toggleCategory(category)}
                    className="flex justify-between items-center w-full text-left font-medium text-white mb-2"
                  >
                    <span>{category}</span>
                    <span>{expandedCategories.has(category) ? "−" : "+"}</span>
                  </button>

                  {expandedCategories.has(category) && (
                    <div className="space-y-3 mt-2">
                      {features[category].map((feature) => (
                        <FeatureItem
                          key={`pro-${feature.name}`}
                          feature={feature.name}
                          available={feature.pro}
                          type="pro"
                        />
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Ultimate Package */}
        <Card
          className={`border-2 bg-black/40 backdrop-blur-sm ${hoveredCard === 2 ? "border-purple-500 shadow-xl shadow-purple-900/20" : "border-purple-900/30"} 
            rounded-2xl transition-all duration-500 flex flex-col overflow-hidden transform ${hoveredCard === 2 ? "scale-105" : ""} h-full`}
          onMouseEnter={() => setHoveredCard(2)}
          onMouseLeave={() => setHoveredCard(null)}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-orange-500/5"></div>

          <CardHeader className="pb-8 pt-8 relative">
            <Badge className="absolute top-4 right-4 bg-gradient-to-r from-purple-500 to-orange-500 text-white hover:from-purple-600 hover:to-orange-600 border-none text-base">
              สุดคุ้ม
            </Badge>
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-400/10 to-orange-400/10 flex items-center justify-center">
                <Gift className="h-10 w-10 text-purple-400" />
              </div>
            </div>
            <CardTitle className="text-3xl font-bold text-center text-white">Ultimate Package</CardTitle>
            <div className="text-center mt-4 flex flex-col items-center justify-center">
              <span className="text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-orange-500 bg-clip-text text-transparent">
                ฿1,199
              </span>
              <span className="text-sm text-gray-400 mt-1">รายเดือน</span>
              <span className="text-base text-gray-400 mt-2">
                หรือ <span className="font-semibold text-purple-400">฿13,999</span> รายปี
              </span>
            </div>
            <CardDescription className="text-center mt-4 text-lg text-gray-400 h-24 flex items-center justify-center">
              สำหรับธุรกิจที่ต้องการฟีเจอร์ครบวงจรเพื่อการเติบโตอย่างก้าวกระโดด
            </CardDescription>
          </CardHeader>

          <CardContent className="flex-grow relative">
            <div className="space-y-4">
              {categories.map((category) => (
                <div key={`ultimate-${category}`} className="border-b border-gray-800 pb-4">
                  <button
                    onClick={() => toggleCategory(category)}
                    className="flex justify-between items-center w-full text-left font-medium text-white mb-2"
                  >
                    <span>{category}</span>
                    <span>{expandedCategories.has(category) ? "−" : "+"}</span>
                  </button>

                  {expandedCategories.has(category) && (
                    <div className="space-y-3 mt-2">
                      {features[category].map((feature) => (
                        <FeatureItem
                          key={`ultimate-${feature.name}`}
                          feature={feature.name}
                          available={feature.ultimate}
                          type="ultimate"
                        />
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Decorative elements at the bottom */}
      <div className="mt-16 text-center relative">
        <p className="text-gray-400 text-lg">
          ติดต่อเราได้ที่{" "}
          <Link
            href={messengerBaseUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-orange-400 font-medium hover:underline"
          >
            facebook:WebRew-D
          </Link>
        </p>

        <div className="absolute -bottom-10 left-1/3 text-purple-400 animate-bounce animation-delay-500">
          <Star className="w-4 h-4 fill-purple-400" />
        </div>
        <div className="absolute -bottom-16 right-1/3 text-pink-400 animate-pulse animation-delay-1500">
          <Star className="w-5 h-5 fill-pink-400" />
        </div>
      </div>
    </div>
  )
}

function FeatureItem({
  feature,
  available,
  type,
}: {
  feature: string
  available: boolean
  type: "basic" | "pro" | "ultimate"
}) {
  const getIconColor = () => {
    if (type === "basic") return "from-orange-400 to-pink-500"
    if (type === "pro") return "from-pink-400 to-purple-500"
    return "from-purple-400 via-pink-500 to-orange-500"
  }

  const getHoverBg = () => {
    if (type === "basic") return "hover:bg-orange-950/30"
    if (type === "pro") return "hover:bg-pink-950/30"
    return "hover:bg-purple-950/30"
  }

  return (
    <div className={`flex items-start p-2 rounded-lg transition-all duration-300 ${getHoverBg()}`}>
      <div
        className={`flex-shrink-0 h-6 w-6 rounded-full flex items-center justify-center mt-0.5 ${
          available
            ? `bg-gradient-to-r ${getIconColor()}`
            : type === "basic"
              ? "bg-red-500/50"
              : type === "pro"
                ? "bg-red-400/50"
                : "bg-red-300/50"
        }`}
      >
        {available ? <Check className="h-4 w-4 text-white" /> : <X className="h-4 w-4 text-white" />}
      </div>
      <span className={`ml-3 text-base text-gray-300 ${!available ? "opacity-50" : ""}`}>{feature}</span>
      {type === "ultimate" && available && <Sparkles className="h-4 w-4 text-orange-400 ml-1 animate-pulse" />}
    </div>
  )
}

